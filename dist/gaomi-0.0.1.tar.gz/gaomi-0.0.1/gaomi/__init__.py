name = "gaomi"
from gaomi import *
from gaomi.nrrd2nii import *
from gaomi.dcm2nii import *
from gaomi.getparams import *